import os
import sys
import json
import shutil
import subprocess
import threading
import tempfile
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_DIR = Path(__file__).resolve().parent
TOOLS_DIR = APP_DIR / "tools"
UPSCALE_EXE = TOOLS_DIR / ("realesrgan-ncnn-vulkan.exe" if os.name == "nt" else "realesrgan-ncnn-vulkan")
FFMPEG = TOOLS_DIR / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")
FFPROBE = TOOLS_DIR / ("ffprobe.exe" if os.name == "nt" else "ffprobe")

def run_cmd(args, log_callback=None):
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, encoding="utf-8", errors="replace")
    for line in p.stdout:
        if log_callback:
            log_callback(line.rstrip())
    code = p.wait()
    if code != 0:
        raise RuntimeError(f"Command failed ({code}): {' '.join(map(str,args))}")
    return code

class UpscalerApp:
    def __init__(self, root):
        self.root = root
        root.title("Personal AI 4K Video Upscaler")
        root.geometry("760x590")
        root.minsize(680, 520)
        self.video = tk.StringVar()
        self.output = tk.StringVar()
        self.scale = tk.StringVar(value="4K UHD (3840 × 2160)")
        self.model = tk.StringVar(value="realesrgan-x4plus")
        self.busy = False

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        main = ttk.Frame(root, padding=18)
        main.pack(fill="both", expand=True)
        ttk.Label(main, text="PERSONAL AI 4K UPSCALER", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(main, text="Local video enhancement • Your files stay on this computer",
                  foreground="#555").pack(anchor="w", pady=(2, 16))

        self._file_row(main, "Input video", self.video, self.pick_video)
        self._file_row(main, "Output file", self.output, self.pick_output)

        opts = ttk.LabelFrame(main, text="Enhancement settings", padding=12)
        opts.pack(fill="x", pady=12)
        ttk.Label(opts, text="Output resolution").grid(row=0, column=0, sticky="w", padx=(0, 12), pady=5)
        ttk.Combobox(opts, textvariable=self.scale, state="readonly",
                     values=["4K UHD (3840 × 2160)", "1080p (1920 × 1080)"]).grid(row=0, column=1, sticky="ew", pady=5)
        ttk.Label(opts, text="AI model").grid(row=1, column=0, sticky="w", padx=(0, 12), pady=5)
        ttk.Combobox(opts, textvariable=self.model, state="readonly",
                     values=["realesrgan-x4plus", "realesrgan-x4plus-anime"]).grid(row=1, column=1, sticky="ew", pady=5)
        opts.columnconfigure(1, weight=1)

        self.start_btn = ttk.Button(main, text="START AI UPSCALING", command=self.start)
        self.start_btn.pack(fill="x", pady=(2, 10), ipady=7)
        self.progress = ttk.Progressbar(main, mode="indeterminate")
        self.progress.pack(fill="x")
        ttk.Label(main, text="Activity log").pack(anchor="w", pady=(12, 4))
        self.log_box = tk.Text(main, height=12, wrap="word", state="disabled",
                               bg="#101820", fg="#e7edf3", insertbackground="white")
        self.log_box.pack(fill="both", expand=True)
        self.log("Ready. Select a video to begin.")

    def _file_row(self, parent, label, var, command):
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=5)
        ttk.Label(row, text=label, width=14).pack(side="left")
        ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Button(row, text="Browse…", command=command).pack(side="right")

    def log(self, message):
        def add():
            self.log_box.configure(state="normal")
            self.log_box.insert("end", message + "\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        self.root.after(0, add)

    def pick_video(self):
        p = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.mov *.mkv *.avi *.webm"), ("All files", "*.*")])
        if p:
            self.video.set(p)
            src = Path(p)
            self.output.set(str(src.with_name(src.stem + "_AI_4K.mp4")))

    def pick_output(self):
        p = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 video", "*.mp4")])
        if p:
            self.output.set(p)

    def check_tools(self):
        missing = [str(x) for x in (FFMPEG, FFPROBE, UPSCALE_EXE) if not x.exists()]
        if missing:
            raise RuntimeError(
                "Required tools are missing:\n" + "\n".join(missing) +
                "\n\nPlease follow SETUP_GUIDE.txt and place the downloaded files in the tools folder."
            )

    def start(self):
        if self.busy:
            return
        if not self.video.get() or not Path(self.video.get()).is_file():
            messagebox.showwarning("Choose a video", "Please select an input video first.")
            return
        if not self.output.get():
            messagebox.showwarning("Choose output", "Please select an output file.")
            return
        self.busy = True
        self.start_btn.configure(state="disabled")
        self.progress.start(12)
        threading.Thread(target=self.process, daemon=True).start()

    def process(self):
        temp_root = None
        try:
            self.check_tools()
            src = Path(self.video.get())
            dest = Path(self.output.get())
            dest.parent.mkdir(parents=True, exist_ok=True)

            probe = subprocess.check_output([
                str(FFPROBE), "-v", "error", "-select_streams", "v:0",
                "-show_entries", "stream=r_frame_rate", "-of", "json", str(src)
            ], text=True)
            data = json.loads(probe)
            rate = data["streams"][0].get("r_frame_rate", "30/1")
            self.log(f"Input: {src.name}")
            self.log(f"Frame rate: {rate}")
            self.log("Extracting video frames…")

            temp_root = Path(tempfile.mkdtemp(prefix="personal_upscale_"))
            frames_in = temp_root / "input_frames"
            frames_out = temp_root / "enhanced_frames"
            frames_in.mkdir()
            frames_out.mkdir()

            run_cmd([str(FFMPEG), "-y", "-i", str(src), "-map", "0:v:0",
                     "-vsync", "0", str(frames_in / "%08d.png")], self.log)

            self.log("Running AI enhancement on frames. This can take a long time on CPU…")
            run_cmd([str(UPSCALE_EXE), "-i", str(frames_in), "-o", str(frames_out),
                     "-n", self.model.get(), "-s", "4", "-f", "png"], self.log)

            resolution_filter = "scale=3840:2160:force_original_aspect_ratio=decrease,pad=3840:2160:(ow-iw)/2:(oh-ih)/2"
            if self.scale.get().startswith("1080p"):
                resolution_filter = "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2"

            self.log("Rebuilding MP4 and restoring original audio…")
            run_cmd([
                str(FFMPEG), "-y", "-framerate", rate, "-i", str(frames_out / "%08d.png"),
                "-i", str(src), "-map", "0:v:0", "-map", "1:a?",
                "-vf", resolution_filter, "-c:v", "libx264", "-preset", "medium",
                "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "copy", "-shortest", str(dest)
            ], self.log)

            self.log(f"SUCCESS: {dest}")
            self.root.after(0, lambda: messagebox.showinfo("Finished", f"Upscaling complete!\n\nSaved to:\n{dest}"))
        except Exception as e:
            self.log("ERROR: " + str(e))
            self.root.after(0, lambda err=str(e): messagebox.showerror("Upscaling failed", err))
        finally:
            if temp_root and temp_root.exists():
                shutil.rmtree(temp_root, ignore_errors=True)
            def finish():
                self.progress.stop()
                self.start_btn.configure(state="normal")
                self.busy = False
            self.root.after(0, finish)

if __name__ == "__main__":
    root = tk.Tk()
    UpscalerApp(root)
    root.mainloop()
